package main

import (
	//"apimethods"
	"gfx"
)

var (
	transactionId []byte
)

func main() {

	for {
		gfx.DrawMenu()
	}

}
