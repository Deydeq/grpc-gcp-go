# gRPC for GCP extensions

Copyright 2019
[The gRPC Authors](https://github.com/grpc/grpc/blob/master/AUTHORS)

## About This Repository

This repo is created to support GCP specific extensions for gRPC. To use the extension features, please refer to [grpcgcp](grpcgcp).

This repo also contains supporting infrastructures such as end2end tests and benchmarks for accessing cloud APIs with gRPC client libraries.
